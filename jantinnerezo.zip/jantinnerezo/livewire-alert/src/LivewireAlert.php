<?php

namespace Jantinnerezo\LivewireAlert;

class LivewireAlert
{
    // Silence is golden
}
