<?php

namespace Bsdev\Ecommerce\DataTables;

use Bsdev\Ecommerce\Models\Category;
use Yajra\DataTables\Html\Button;
use Yajra\DataTables\Html\Column;
use Yajra\DataTables\Services\DataTable;

class CategoryDataTable extends DataTable
{
    /**
     * Build DataTable class.
     *
     * @param mixed $query Results from query() method.
     * @return \Yajra\DataTables\DataTableAbstract
     */
    public function dataTable($query)
    {
        return datatables()
            ->eloquent($query)
            ->editColumn('action', function (Category $category) {
                return '<div style="display:flex;"><a class="" href=' . route('product.categories.edit', $category->id) . '><i class="fa fa-edit"></i></a><a class="" href=' . route('product.categories.show', $category->slug) . '><i class="fa fa-eye"></i></a><form method="POST" style="display:inline; margin-left:10px" action="' . route('product.categories.destroy', $category->id) . '"><input type="hidden" name="_method" value="DELETE"><input type="hidden" name="_token" value="' . csrf_token() . '"><a class="delete-class" data-href=' . route('product.categories.destroy', $category->id) . '><i class="fa fa-trash" style="color:red;"></i></a></form>';
            })
            ->editColumn('category', function (Category $category) {
                return $category->category->name ?? '';
            })
            ->editColumn('image', function (Category $category) {
                return '<img src=' . asset('storage/' . $category->image) . ' height="100px">';
            })

            ->editColumn('status', function (Category $category) {
                return $category->status ? '<span style="color:white;background-color:green; padding:5px; border-radius:10px;">Published</span>' : '<span style="color:white;background-color:red; padding:5px; border-radius:10px;">Unpublished</span>';
            })
            ->editColumn('show_in_home', function (Category $category) {
                return $category->show_in_home ? '<span style="color:white;background-color:green; padding:5px; border-radius:10px;">Yes</span>' : '<span style="color:white;background-color:red; padding:5px; border-radius:10px;">No</span>';
            })
            ->editColumn('show_product_in_home', function (Category $category) {
                return $category->show_product_in_home ? '<span style="color:white;background-color:green; padding:5px; border-radius:10px;">Yes</span>' : '<span style="color:white;background-color:red; padding:5px; border-radius:10px;">No</span>';
            })
            ->escapeColumns([]);
    }

    /**
     * Get query source of dataTable.
     *
     * @param \App\Models\Category $model
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function query(Category $model)
    {
        return $model->with(['category', 'categories'])->newQuery();
    }

    /**
     * Optional method if you want to use html builder.
     *
     * @return \Yajra\DataTables\Html\Builder
     */
    public function html()
    {
        return $this->builder()
            ->setTableId('category-table')
            ->columns($this->getColumns())
            ->minifiedAjax()
            ->dom('Bfrtip')
            ->orderBy(1)
            ->buttons(
                Button::make('create'),
                Button::make('export'),
                Button::make('print'),
                Button::make('reset'),
                Button::make('reload')
            );
    }

    /**
     * Get columns.
     *
     * @return array
     */
    protected function getColumns()
    {
        return [
            Column::make('id'),
            Column::make('name'),
            Column::make('slug'),
            Column::make('category')
                ->data('category')
                ->name('category.name')
                ->searchable(false),
            Column::make('image'),
            Column::make('status'),
            Column::make('show_in_home'),
            Column::make('show_product_in_home'),
            Column::computed('action')
                ->exportable(false)
                ->printable(false)
                ->width(60)
                ->addClass('text-center'),
        ];
    }

    /**
     * Get filename for export.
     *
     * @return string
     */
    protected function filename()
    {
        return 'Category_' . date('YmdHis');
    }
}
