<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <title>Invoice</title>

    <!-- Favicon -->
    <link rel="icon" href="./images/favicon.png" type="image/x-icon" />

    <style>
        *,
        *::after,
        *::before {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Rubik, sans-serif;
            font-size: 14px;
            line-height: 24px;
            color: black;
            overflow-x: hidden;
            scroll-behavior: smooth;
            -webkit-font-smoothing: antialiased;
            width: 100%;
            margin: auto;
        }

        .container {
            width: 100%;
            padding-right: 15px;
            padding-left: 15px;
            margin-right: auto;
            margin-left: auto;
            max-width: 1140px;
        }

        .bx-shadow {
            box-shadow: 0 1px 3px rgb(0 0 0 / 9%);
        }

        .p-4 {
            padding: 1.5rem !important;
        }

        .my-5 {
            margin-bottom: 3rem !important;
        }

        .row {
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -ms-flex-wrap: wrap;
            flex-wrap: wrap;
            margin-right: -15px;
            margin-left: -15px;
        }

        .col-12,
        .col-6 {
            position: relative;
            width: 100%;
            min-height: 1px;
            padding-right: 15px;
            padding-left: 15px;
        }

        .col-12 {
            -webkit-box-flex: 0;
            -ms-flex: 0 0 100%;
            flex: 0 0 100%;
            max-width: 100%;
        }

        .col-6 {
            -webkit-box-flex: 0;
            -ms-flex: 0 0 50%;
            flex: 0 0 50%;
            max-width: 50%;
        }

        ol,
        ul {
            margin: 0;
            padding: 0 0 0 17px;
            list-style: none;
        }

        .mb-0 {
            margin-bottom: 0 !important;
        }

        .mb-4 {
            margin-bottom: 1.5rem;
        }

        .pull-left {
            float: left;
        }

        .list {}

        .list-unstyled {
            padding-left: 0;
            list-style: none;
        }

        .text-left {
            text-align: left !important;
        }

        .font-weight-bold {
            font-weight: 700 !important;
        }

        a {
            font-family: Rubik, sans-serif;
            color: inherit;
            text-decoration: none;
            background-color: transparent;
        }

        a:hover {
            color: #bf1b1b;
        }

        h4 {
            line-height: 1.428;
            font-family: Rubik, sans-serif;
            font-weight: 400;
            color: black;
            margin: 0;
            padding: 0;
        }

        h4 {
            font-size: 20px;
        }

        h5 {
            font-size: 18px;
        }

        .text-sm-right {
            text-align: right !important;
        }

        .text-right {
            text-align: right !important;
        }

        .mb-2 {
            margin-bottom: 0.5rem;
        }

        .mt-2 {
            margin-top: 0.5rem;
        }

        .flex-md-wrap {
            -ms-flex-wrap: wrap !important;
            flex-wrap: wrap !important;
        }

        .d-md-flex {
            display: -webkit-box !important;
            display: -ms-flexbox !important;
            display: flex !important;
        }

        .ml-auto,
        .mx-auto {
            margin-left: auto !important;
        }

        .table-responsive {
            display: block;
            width: 100%;
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
            -ms-overflow-style: -ms-autohiding-scrollbar;
        }

        table {
            border: 1px solid #f3f3f3;
            border-collapse: collapse;
            border-spacing: 0;
            table-layout: auto;
            width: 100%;
            max-width: 100%;
            margin-bottom: 1rem;
            background-color: transparent;
        }

        .table thead th {
            vertical-align: bottom;
            vertical-align: top;
            border-top: 1px solid #dee2e6;
        }

        td,
        th {
            border: 1px solid #f3f3f3;
            padding: 10px;
            font-weight: 400;
        }

        hr {
            margin-top: 1rem;
            margin-bottom: 1rem;
            border: 0;
            border-top: 1px solid rgba(0, 0, 0, 0.1);
        }

        .text-center {
            text-align: center;
        }

        .img-fluid {
            width: 140px;
            height: 80px;
        }

        .top {
            border: none !important;
        }

        .top tr,
        .top td,
        .top {
            border: none !important;
        }
    </style>
</head>

<body>
    <div class="gadi-invoice my-5" style="color: #333">
        <div class="container bx-shadow p-4">
            <div class="row">
                <div class="col-12">
                    <div class="">
                        {{-- gadi Logo and Invoice --}}
                        
                        
                        
                        <center style="margin-top:-15px;">
                            <strong>
                                CLICKMART.COM.NP
                                </strong>
                              
                                @php($site = Theme::siteSetup())
                                  
                                  
                                  
                                           <br>
                                                <a href="tel:{{ $site->phone }}">
                                                    {{ $site->phone }}</a>          
                            <br>
                            <a href="mailto:{{ $site->email }}">
                                                    {{ $site->email }}</a>
                                              
                                                    <BR>
                                                      {{ date('M-d-Y') }}
                                          
                        </center>
                        
                
                        <hr />
                        {{-- invoice to and payment details --}}
                        <div class="table-responsive" style="margin-top:-20px;">
                            <table class="text-left top">
                                <tr>
                                    
                                    <td>
                                      
                                               <STRONG>
                                         ORDER SUMMARY:
                                         </STRONG>
                                          
                                            <ul class="list list-unstyled mb-0">
                                                  <li>ORDER No: {{ $order->id }}</li>
                                                   <li>Order Date: {{ date('M-d-Y',strtotime($order->created_at)) }}</li>
                                                  <li>Delivery Date: {{ date('M-d-Y',strtotime($order->created_at)) }}</li>
                                                   <li>
                                                      Payment Method:
                                                        {{ $order->payment_method }}
                                                    </li>
                                                    
                            
                                               
                                            </ul>
                                       
                                    </td>
                                    
                                     <td >
                                         <STRONG>
                                             Billing Address:
                                         </STRONG>
                                    
                                        <ul class="list list-unstyled mb-0">
                                           <li>FULL NAME: {{ $order->user->name }}</li>
                                           
                                              <li>
                                                        Permanent Address:
                                                    {{ $order->user->address }}
                                                
                                                    {{ $order->user->address2 }}
                                                </li>
                                           
                                                <li>
                                                    phone:
                                                    {{ $order->user->phone }}
                                                </li>
                                        
                                           
                                                 <li>
                                                    <a href="mailto:{{ $order->user->email }}">Email:
                                                        {{ $order->user->email }}</a>
                                                </li>
                                          
                                           
                                        </ul>
                                    </td>

                                    <td class="text-right" style="vertical-align: top">
                                        <div class="">
                                               <STRONG>
                                          Shipping Address:
                                         </STRONG>
                                         
                                           
                                                {{-- if payment method is esewa --}}
                                                <ul class="list list-unstyled mb-0">
                                                  
                                                <li>
                                                  Address:
                                                  @foreach ($order->shipping_detail??[] as $key=>$val)
                                                    {{ $key }}:{{ $val }}<br> @if(!$loop->last) @endif
                                                    @endforeach
                                                </li>
                                                
                                                   
                                                </ul>
                                           
                                        </div>
                                    </td>
                                </tr>
                            </table>
                        </div>

                        <div class="table-responsive" style="margin-top: 12px;">
                            <table class="table">
                                <thead class="gadi-invoice-head" style="background: #bf1b1b; color: #fff;">
                                    <tr>
                                        <th>S.N</th>
                                        <th>Product</th>
                                        <th>Price</th>
                                        <th>Qty</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody class="gadi-invoice-body" style="color: #333; text-align: center">
                                    @php($total=0)
                                    @foreach($order->cart_items as $item)
                                    @php($total+=$item->quantity*$item->price)
                                    @php($product = $item->product)
                                    <tr>
                                        <td>{{ $loop->index+1 }}</td>
                                        <td>
                                            @if($product->has_variation)
                                            {{ $item->variation->title??'Deleted Product' }}<br>
                                            <ul>
                                                @foreach ($item->getAttributeArray() as $attribute)
                                                <li>
                                                    {{ $attribute->name }}:
                                                    @php($name =
                                                    $attribute->values->where('id',$item->variations[$attribute->id])->pluck('name'))
                                                    <span>{{ $name[0] }}</span>
                                                </li>
                                                @endforeach
                                            </ul>
                                            @else

                                            {{ $item->product->title??'Deleted Product' }}<br>
                                            @endif

                                        </td>
                                        <td>Rs. {{ $item->price }}</td>
                                        <td>{{ $item->quantity }}</td>
                                        <td>Rs. {{ $item->quantity*$item->price }}</td>
                                        </td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>



                        <table style="width: 50%; margin-left: auto">
                            <tbody>
                                <tr>
                                    <th class="text-left">Subtotal:</th>
                                    <td class="text-right">Rs. {{ $total }}</td>
                                </tr>
                                <tr>
                                    <th class="text-left">Shipping:</th>
                                    <td class="text-right">{{ $order->shipping_cost }}</td>
                                </tr>
                                <tr class="gadi-invoice-total" style="background: #bf1b1b; color: #fff">
                                    <th class="text-left">Total:</th>
                                    <td class="text-right font-weight-bold">Rs.
                                        {{ $total+$order->shipping_cost }}</td>
                                </tr>
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
