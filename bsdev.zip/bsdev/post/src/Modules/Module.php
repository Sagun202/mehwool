<?php
namespace Bsdev\Services\Modules;

class Module
{

    public function getModuleName()
    {
        return 'Service';
    }

    public function getMenu()
    {

    }

}
