

<i style="font-weight: 900; font-size:30px;" class="bi bi-cart3"></i>
<span class="cart-count">{{ $items }}</span>

