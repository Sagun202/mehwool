
     <a href="javascript:void(0);"  class="btn-product-icon btn-expandable " wire:click="addToWishList"  >  <i class="bi bi-clipboard2-heart"></i> <span>  Add to wishlist</span></a>
     
