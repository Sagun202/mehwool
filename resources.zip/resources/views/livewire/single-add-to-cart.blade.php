






     <a  class="btn-product-icon btn-expandable " title="Add to Cart" wire:click="addToCart" >  <i class="bi bi-cart-plus"></i> <span>  Add to Cart</span></a>
     
