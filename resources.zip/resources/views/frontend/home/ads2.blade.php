    <a href="{{ $ads->link }}" target="_blank"><img src="{{ asset('storage/'.$ads->image) }}" alt="{{ $ads->title }}" />
    </a>
