
      
               <a href="{{ $ads->link }}"  ><img src="{{ asset('storage/'.$ads->image) }}" alt="{{ $ads->title }}"></a>
   