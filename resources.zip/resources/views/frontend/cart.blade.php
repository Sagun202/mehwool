@extends('frontend.layouts.master')

@section('content')
<div class="contain" style="background: white"  >
    <div class="cart-page">
        @livewire('cart')
    </div>
</div>
@endsection