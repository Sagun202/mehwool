@extends('frontend.layouts.master')

@section('content')
<div class="container">
    <div class="checkout-page">
        @livewire('checkout')
    </div>
</div>
@endsection